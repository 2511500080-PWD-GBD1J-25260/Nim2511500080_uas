package com.marsyamaharani.projectUASDPM

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ResultActivity : AppCompatActivity() {
    var tvNama: TextView? = null
    var tvNim: TextView? = null
    var tvKelamin: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result2511500080)

        tvNama = findViewById(R.id.tvNama)
        tvNim = findViewById(R.id.tvNim)
        tvKelamin = findViewById(R.id.tvKelamin)

        val nama = intent.getStringExtra("nama")
        val nim = intent.getStringExtra("nim")
        val jk = intent.getStringExtra("jk")

        tvNama!!.text = getString(R.string.nama, nama)
        tvNim!!.text = getString(R.string.nim, nim)
        tvKelamin!!.text = getString(R.string.jenis_kelamin, jk)
    }
}
package com.marsyamaharani.projectUASDPM

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    var tvNama: TextView? = null
    var tvNim: TextView? = null
    var tvKelamin: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result2511500080)

        tvNama = findViewById<TextView?>(R.id.tvNama)
        tvNim = findViewById<TextView?>(R.id.tvNim)
        tvKelamin = findViewById<TextView?>(R.id.tvKelamin)

        val nama = getIntent().getStringExtra("nama")
        val nim = getIntent().getStringExtra("nim")
        val jk = getIntent().getStringExtra("jk")

        tvNama!!.setText("Nama : " + nama)
        tvNim!!.setText("NIM : " + nim)
        tvKelamin!!.setText("Jenis Kelamin : " + jk)
    }
}